/** @jest-environment jsdom */
import JsonTableViewer from '../src/JsonTableViewer.js';
test('renders', () => {
  customElements.define('json-table-viewer-test', JsonTableViewer);
  const el = document.createElement('json-table-viewer-test');
  document.body.appendChild(el);
  el.data = [{name:'Jan',age:25}];
  el.render();
  expect(el.shadowRoot.querySelectorAll('th').length).toBeGreaterThan(0);
});